﻿namespace CRUD3.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;

    public class Rol
    {
        public int RolId { get; set; }

        [Required]
        [StringLength(35)]
        public string Name { get; set; }

        [Required]
        public DateTime RegisterDate { get; set; }

        [Required]
        [StringLength(50)]
        public string Status { get; set; }
    }

}
