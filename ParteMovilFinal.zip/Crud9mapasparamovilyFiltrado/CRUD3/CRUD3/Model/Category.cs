﻿namespace CRUD3.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class Category
    {
        [Key]
        public int CategoryId { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [Required]
        public DateTime RegisterDate { get; set; } = DateTime.Now;

        public DateTime? LastUpdate { get; set; }

        [Required]
        [StringLength(50)]
        public string Status { get; set; } = "1";

        public int? UserRegister { get; set; }
        public int? UserLastUpdate { get; set; }
    }


}
