﻿namespace CRUD3.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;

    public class Person
    {
        public int PersonId { get; set; }

        [Required]
        [StringLength(60)]
        public string Name { get; set; }

        [Required]
        [StringLength(35)]
        public string Lastname { get; set; }

        [StringLength(35)]
        public string SecondLastname { get; set; }

        [Required]
        [StringLength(15)]
        public string IdentityNumber { get; set; }

        [Required]
        [StringLength(20)]
        public string Telephone { get; set; }

        [Required]
        [StringLength(60)]
        public string Email { get; set; }

        [Required]
        [StringLength(100)]
        public string HomeAddress { get; set; }

        [Required]
        public DateTime DateBirth { get; set; }

        [Required]
        [StringLength(20)]
        public string Gender { get; set; }

        [Required]
        public DateTime RegisterDate { get; set; }

        public DateTime? LastUpdate { get; set; }

        [Required]
        public byte Status { get; set; }

        public int? UserRegister { get; set; }
        public int? UserLastUpdate { get; set; }
    }


}
