using CRUD3.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;

namespace CRUD3.Pages.site
{
    public class PhotosModel : PageModel
    {
        private readonly CRUD3.Data.ApplicationDbContext _context;

        public PhotosModel(CRUD3.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<PhotoTouristSite> PhotoTouristSite { get; set; } = default!;

        public async Task OnGetAsync()
        {
            if (_context.PhotoTouristSites != null)
            {
                PhotoTouristSite = await _context.PhotoTouristSites
                .Include(p => p.TouristSite).ToListAsync();
            }
        }

        private byte[] DecryptPhoto(byte[] encryptedPhoto, byte[] key, byte[] iv)
        {
            using (var cryptoProvider = new AesCryptoServiceProvider())
            {
                cryptoProvider.Key = key;
                cryptoProvider.IV = iv;

                using (var decryptor = cryptoProvider.CreateDecryptor(cryptoProvider.Key, cryptoProvider.IV))
                {
                    return decryptor.TransformFinalBlock(encryptedPhoto, 0, encryptedPhoto.Length);
                }
            }
        }
    }
}
