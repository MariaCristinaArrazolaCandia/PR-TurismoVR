using CRUD3.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace CRUD3.Pages.site
{
    public class DetailsModel : PageModel
    {
        private readonly CRUD3.Data.ApplicationDbContext _context;

        public DetailsModel(CRUD3.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public TouristSite TouristSite { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.TouristSites == null)
            {
                return NotFound();
            }

            var touristsite = await _context.TouristSites.FirstOrDefaultAsync(m => m.TouristSiteId == id);
            if (touristsite == null)
            {
                return NotFound();
            }
            else
            {
                TouristSite = touristsite;
            }
            return Page();
        }
    }
}