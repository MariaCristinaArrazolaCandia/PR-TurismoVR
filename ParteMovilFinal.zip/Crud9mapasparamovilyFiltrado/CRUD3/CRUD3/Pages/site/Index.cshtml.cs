using CRUD3.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace CRUD3.Pages.site
{
    public class IndexModel : PageModel
    {
        private readonly CRUD3.Data.ApplicationDbContext _context;

        public IndexModel(CRUD3.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public List<Category> Categories { get; set; }

        public IList<TouristSite> TouristSite { get; set; } = default!;

        public async Task OnGetAsync(int? categoryId)
        {
            IQueryable<TouristSite> touristSitesQuery = _context.TouristSites;

            if (categoryId.HasValue)
            {
                touristSitesQuery = touristSitesQuery.Where(ts => ts.CategoryId == categoryId);
            }

            TouristSite = await touristSitesQuery.ToListAsync();

            Categories = await _context.Categories.ToListAsync();
        }

    }
}
