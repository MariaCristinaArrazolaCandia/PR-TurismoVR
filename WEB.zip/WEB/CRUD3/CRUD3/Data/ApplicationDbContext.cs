﻿namespace CRUD3.Data

{
    using CRUD3.Model;
    using Microsoft.EntityFrameworkCore;
    using System.Collections.Generic;

    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Horary> Horaries { get; set; }
        public DbSet<Person> People { get; set; }
        public DbSet<PhotoTouristSite> PhotoTouristSites { get; set; }
        public DbSet<Rol> Roles { get; set; }
        public DbSet<TouristSite> TouristSites { get; set; }
        public DbSet<User> Users { get; set; }

        // Add any additional configurations or relationships here.
    }

}
