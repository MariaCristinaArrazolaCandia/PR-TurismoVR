﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using CRUD3.Data;
using CRUD3.Model;

namespace CRUD3.Pages.sites
{
    public class DeleteModel : PageModel
    {
        private readonly CRUD3.Data.ApplicationDbContext _context;

        public DeleteModel(CRUD3.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
      public TouristSite TouristSite { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.TouristSites == null)
            {
                return NotFound();
            }

            var touristsite = await _context.TouristSites.FirstOrDefaultAsync(m => m.TouristSiteId == id);

            if (touristsite == null)
            {
                return NotFound();
            }
            else 
            {
                TouristSite = touristsite;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null || _context.TouristSites == null)
            {
                return NotFound();
            }
            var touristsite = await _context.TouristSites.FindAsync(id);

            if (touristsite != null)
            {
                TouristSite = touristsite;
                _context.TouristSites.Remove(TouristSite);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
