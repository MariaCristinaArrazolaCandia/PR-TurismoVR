﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CRUD3.Data;
using CRUD3.Model;

namespace CRUD3.Pages.photo
{
    public class EditModel : PageModel
    {
        private readonly CRUD3.Data.ApplicationDbContext _context;

        public EditModel(CRUD3.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public PhotoTouristSite PhotoTouristSite { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.PhotoTouristSites == null)
            {
                return NotFound();
            }

            var phototouristsite =  await _context.PhotoTouristSites.FirstOrDefaultAsync(m => m.PhotoTouristSiteId == id);
            if (phototouristsite == null)
            {
                return NotFound();
            }
            PhotoTouristSite = phototouristsite;
           ViewData["TouristSiteId"] = new SelectList(_context.TouristSites, "TouristSiteId", "TouristSiteId");
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(PhotoTouristSite).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PhotoTouristSiteExists(PhotoTouristSite.PhotoTouristSiteId))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool PhotoTouristSiteExists(int id)
        {
          return (_context.PhotoTouristSites?.Any(e => e.PhotoTouristSiteId == id)).GetValueOrDefault();
        }
    }
}
