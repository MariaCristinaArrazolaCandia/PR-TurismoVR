﻿namespace CRUD3.Model
{
    using CRUD3.Data;
    using System;
    using System.ComponentModel.DataAnnotations;

        public class TouristSite
        {
            public int TouristSiteId { get; set; }

            //[Required]
            //[StringLength(100)]
            //[UniqueTouristSiteName]
            public string Name { get; set; }

            //[Required]
            //[StringLength(100)]
            public string Address { get; set; }

            //[Required]
            //[StringLength(100)]
            public string Description { get; set; }

            //[Required]
            //[StringLength(20)]
            public string PhoneNumber { get; set; }

            //[Required]
            //[StringLength(60)]
            public string Email { get; set; }

            
            public DateTime RegisterDate { get; set; } = DateTime.Now;

            public DateTime? LastUpdate { get; set; }

            ////[Required]
            ////[StringLength(50)]
            public string Status { get; set; } = "1";

            public int? UserRegister { get; set; }
            public int? UserLastUpdate { get; set; }

            //[Required]
            public string Longitude { get; set; }

            //[Required]
            public string Latitude { get; set; }

            public int? CategoryId { get; set; }
            public Category Category { get; set; }
        }


        //public class UniqueTouristSiteNameAttribute : ValidationAttribute
        //{
        //    protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        //    {
        //        var _context = (ApplicationDbContext)validationContext.GetService(typeof(ApplicationDbContext));
        //        var touristSite = _context.TouristSites.FirstOrDefault(ts => ts.Name == value.ToString());

        //        if (touristSite != null)
        //        {
        //            return new ValidationResult("A tourist site with this name already exists.");
        //        }

        //        return ValidationResult.Success;
        //    }
        //}

    }
