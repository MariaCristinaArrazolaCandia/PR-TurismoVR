﻿namespace CRUD3.Model
{
    using Microsoft.AspNetCore.Mvc;
    using System;
    using System.ComponentModel.DataAnnotations;

    public class PhotoTouristSite
    {
        public int PhotoTouristSiteId { get; set; }

        //[Required]
        public byte[] Photo { get; set; }

        // Nuevas propiedades para la clave y el IV
        public byte[] EncryptionKey { get; set; }
        public byte[] EncryptionIV { get; set; }

        public int? UserRegister { get; set; }
        public int? UserLastUpdate { get; set; }

        //[Required]
        public DateTime RegisterDate { get; set; } =DateTime.Now;

        public DateTime? LastUpdate { get; set; }

        /*[Required]
        [StringLength(50)]*/
        public string Status { get; set; } = "1";

        public int TouristSiteId { get; set; }
        public TouristSite TouristSite { get; set; }

        
    }


}
