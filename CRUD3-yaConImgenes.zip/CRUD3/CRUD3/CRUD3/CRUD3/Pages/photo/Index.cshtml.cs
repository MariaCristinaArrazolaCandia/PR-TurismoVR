﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using CRUD3.Data;
using CRUD3.Model;

namespace CRUD3.Pages.photo
{
    public class IndexModel : PageModel
    {
        private readonly CRUD3.Data.ApplicationDbContext _context;

        public IndexModel(CRUD3.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<PhotoTouristSite> PhotoTouristSite { get;set; } = default!;

        public async Task OnGetAsync()
        {
            if (_context.PhotoTouristSites != null)
            {
                PhotoTouristSite = await _context.PhotoTouristSites
                .Include(p => p.TouristSite).ToListAsync();
            }
        }
    }
}
