﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using CRUD3.Data;
using System.Security.Cryptography;
using CRUD3.Model;

namespace CRUD3.Pages.photo
{
    public class CreateModel : PageModel
    {
        private readonly CRUD3.Data.ApplicationDbContext _context;

        public CreateModel(CRUD3.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
        ViewData["TouristSiteId"] = new SelectList(_context.TouristSites, "TouristSiteId", "Name");
            return Page();
        }
        [BindProperty]
        public PhotoTouristSite PhotoTouristSite { get; set; }

        // Aquí se define UploadedPhoto
        [BindProperty]
        public IFormFile UploadedPhoto { get; set; }


        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {

           // if (UploadedPhoto == null)
            //{
                // Manejar el caso en el que no se cargó ninguna imagen
               // ModelState.AddModelError("UploadedPhoto", "Please select an image to upload.");
             //   return Page();
           // }


            //if (!ModelState.IsValid)
            //{
            //    ViewData["TouristSiteId"] = new SelectList(_context.TouristSites, "TouristSiteId", "Name");
            //    return Page();
            //}

            using (var memoryStream = new MemoryStream())
            {
                await UploadedPhoto.CopyToAsync(memoryStream);

                // Aquí puedes agregar la lógica de encriptación si ya tienes una clave y un algoritmo en mente
                // Por ejemplo, podrías utilizar AES para encriptar los datos de la imagen.
                // El siguiente código es un ejemplo simplificado:
                byte[] encryptedPhoto;
                using (var cryptoProvider = new AesCryptoServiceProvider())
                {
                    cryptoProvider.GenerateKey();
                    cryptoProvider.GenerateIV();

                    // Guarda la clave y el IV de manera segura para su uso en la desencriptación.
                    byte[] key = cryptoProvider.Key;
                    byte[] iv = cryptoProvider.IV;
                    using (var encryptor = cryptoProvider.CreateEncryptor(cryptoProvider.Key, cryptoProvider.IV))
                    {
                        encryptedPhoto = encryptor.TransformFinalBlock(memoryStream.ToArray(), 0, (int)memoryStream.Length);
                    }
                }

                // Asigna la foto encriptada al modelo
                PhotoTouristSite.Photo = encryptedPhoto;
            }

            // Resto de tu lógica para guardar el PhotoTouristSite
            _context.PhotoTouristSites.Add(PhotoTouristSite);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}