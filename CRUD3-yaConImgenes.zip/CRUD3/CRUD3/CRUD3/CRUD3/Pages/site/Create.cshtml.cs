﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using CRUD3.Data;
using CRUD3.Model;
using Microsoft.EntityFrameworkCore;

namespace CRUD3.Pages.site
{
    public class CreateModel : PageModel
    {
        private readonly CRUD3.Data.ApplicationDbContext _context;

        public CreateModel(CRUD3.Data.ApplicationDbContext context)
        {
            _context = context;
        }


        [BindProperty]
        public TouristSite TouristSite { get; set; }

        public IEnumerable<Category> Categories { get; set; }

        public async Task OnGetAsync()
        {
            Categories = await _context.Categories.ToListAsync();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var isNameUnique = await _context.TouristSites.AnyAsync(x => x.Name == TouristSite.Name);

            if (!isNameUnique)
            {
                ModelState.AddModelError("Name", "This name is already in use. Please enter a unique name.");
                return Page();
            }

            _context.TouristSites.Add(TouristSite);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
