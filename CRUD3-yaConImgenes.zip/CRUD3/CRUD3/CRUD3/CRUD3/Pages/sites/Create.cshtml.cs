﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using CRUD3.Data;
using CRUD3.Model;

namespace CRUD3.Pages.sites
{
    public class CreateModel : PageModel
    {
        private readonly CRUD3.Data.ApplicationDbContext _context;

        public CreateModel(CRUD3.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            ViewData["CategoryId"] = new SelectList(_context.Categories, "CategoryId", "Name");
            return Page();
        }

        [BindProperty]
        public TouristSite TouristSite { get; set; } = default!;
        

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
          //if (!ModelState.IsValid || _context.TouristSites == null || TouristSite == null)
          //  {
          //      return Page();
          //  }

            _context.TouristSites.Add(TouristSite);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
