﻿namespace CRUD3.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;

    public class User
    {
        public int UserId { get; set; }

        [Required]
        [StringLength(35)]
        public string Username { get; set; }

        [Required]
        [StringLength(25)]
        public string Password { get; set; }

        public int RolId { get; set; }
        public Rol Rol { get; set; }

        public int? PersonId { get; set; }
        public Person Person { get; set; }

        [Required]
        public DateTime RegisterDate { get; set; }

        public DateTime? LastUpdate { get; set; }

        [Required]
        [StringLength(50)]
        public string Status { get; set; }

        public int? UserRegister { get; set; }
        public int? UserLastUpdate { get; set; }
    }


}
