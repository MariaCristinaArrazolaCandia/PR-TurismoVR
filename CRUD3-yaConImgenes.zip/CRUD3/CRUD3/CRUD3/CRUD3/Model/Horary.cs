﻿namespace CRUD3.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;

    public class Horary
    {
        public int HoraryId { get; set; }

        [Required]
        public TimeSpan OpeningHour { get; set; }

        [Required]
        public TimeSpan ClosingHour { get; set; }

        [Required]
        [StringLength(10)]
        public string DpeningDays { get; set; }

        [Required]
        public DateTime RegisterDate { get; set; }

        public DateTime? LastUpdate { get; set; }

        [Required]
        public byte Status { get; set; }

        public int? UserRegister { get; set; }
        public int? UserLastUpdate { get; set; }

        public int TouristSiteId { get; set; }
        public TouristSite TouristSite { get; set; }
    }


}
